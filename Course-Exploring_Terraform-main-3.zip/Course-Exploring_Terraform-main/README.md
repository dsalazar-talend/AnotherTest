# Course-Exploring_Terraform
Repo to host the source code from the Terraform tutorial

Okta AWS CLI: https://github.com/jmhale/okta-awscli

To use tf_setup.sh you need to do a few things:
- Edit the scripts two variables in the Manual section
  - un variable should be set to your work email
  - al variable should be set to the Okta tile link for AWS

Once you run it, you will be prompted at the end to configure okta-awscli
- Enter password for Okta
- Complete MFA

For this to work you have to edit your main.tf provider’s profile to “secops-nonprod”

```
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 2.70"
    }
  }
}
provider "aws" {
  profile = "secops-nonprod"  <--this one
  region  = "us-west-2"
}
resource "aws_instance" "example" {
  ami           = "ami-830c94e3"
  instance_type = "t2.micro"
}
```


You can use this with aws by specifying a profile: aws s3 ls --profile secops-nonprod
You can use this with terraform without doing anything special: terraform apply
