#! /bin/bash
# This is designed to install all the requirements for use
# on a Debian based Linux OS, like Ubuntu for example.

##################
# Manual Changes #
##################

# 1) Enter your Okta Username / work email
un=""

# 2) Enter your App Link / AWS tile link
al=""

################
# Prerequisits #
################

# 1) Update date time
sudo date -s "$(wget -qSO- --max-redirect=0 google.com 2>&1 | grep Date: | cut -d' ' -f5-8)Z"

# 2) Install Curl
sudo apt install curl

#####################
# Install Terraform #
#####################

# 1) Add HashiCorp GPG Key
curl -fsSL https://apt.releases.hashicorp.com/gpg | sudo apt-key add -

# 2) Add the official HashiCorp Linux repository.
sudo apt-add-repository "deb [arch=amd64] https://apt.releases.hashicorp.com $(lsb_release -cs) main"

# 3) Update and install terraform
sudo apt-get update && sudo apt-get install terraform

# 4) Confirm Terraform Installation
terraform -v

##################
# Install Docker #
##################

# 1) Add Docker GPG Key
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -

# 2) Add the official Docker x86_64 Linux Library
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"

# 3) Update and install docker
sudo apt-get update && sudo apt-get install -y docker-ce docker-ce-cli containerd.io

# 4) Confirm Docker Installation
docker -v

####################
# Install Okta CLI #
####################

# 1) Install Pip3
sudo apt-get install -y python3-pip

# 2) Install AWS CLI
pip3 install awscli --upgrade --user

# 3) Install Okta CLI
pip3 install okta-awscli
# pip3 install "okta-awscli[U2F]" # YubiKey support


####################
# Configure Docker #
#######t#############

# 1) Create Docker Group
sudo groupadd docker

# 2) Add User to Group
sudo usermod -aG docker ${USER}

# 3) Modify Docker Sock Permissions
sudo chmod 666 /var/run/docker.sock

######################
# Configure Okta CLI #
######################

# 1) Create Template
config=$"\
[secops-nonprod]\n \
base-url = talend.okta.com\n \
username = ${un}\n \
factor   = OKTA\n \
profile  = secops-nonprod\n \
role = arn:aws:iam::482961112712:role/Okta-FullAdmin\n \
app-link = ${al}\n \
duration = 3600"

# 2) Fill Config File with template
echo -e "$config" > ~/.okta-aws

# 3) Configure AWSCLI
export PATH=$HOME/.local/bin:$PATH
source ~/.bashrc
chmod +x ~/.local/bin/aws

# 4) Configure AWSCLI Profile
aws configure set region us-east-1 --profile secops-nonprod
aws configure set output text --profile secops-nonprod

# 5) Configure okta-awscli
okta-awscli --okta-profile secops-nonprod --profile secops-nonprod
